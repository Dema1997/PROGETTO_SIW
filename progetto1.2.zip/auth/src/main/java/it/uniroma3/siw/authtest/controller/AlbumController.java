package it.uniroma3.siw.authtest.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.authtest.model.Album;
import it.uniroma3.siw.authtest.model.Fotografo;
import it.uniroma3.siw.authtest.service.AlbumService;
import it.uniroma3.siw.authtest.service.FotografoService;

@Controller
public class AlbumController {


	@Autowired
	private AlbumService albumService;

	@Autowired
	private FotografoService fotografoService;


	public AlbumController() {
		super();
	}

	@RequestMapping(value="/album", method= RequestMethod.POST)
	public String newAlbum(@Valid@ModelAttribute("album")Album album,Model model) {

  
		this.albumService.inserisci(album);
		
		model.addAttribute("fotografi", this.fotografoService.tutti());
		
		model.addAttribute("fotografo",new Fotografo());

		return "fotografiAdmin";

	}

}
