package it.uniroma3.siw.authtest.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import it.uniroma3.siw.authtest.model.Album;
import it.uniroma3.siw.authtest.model.Fotografia;


public interface FotografiaRepository extends CrudRepository<Fotografia,Long>{
	List<Fotografia> findByAlbum(Album album);
}
