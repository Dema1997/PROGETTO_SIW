package it.uniroma3.siw.authtest.repository;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.authtest.model.Fotografo;


public interface FotografoRepository extends CrudRepository<Fotografo,Long> {

}
